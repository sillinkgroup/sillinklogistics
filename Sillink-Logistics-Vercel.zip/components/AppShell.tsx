import Sidebar from './Sidebar';
export default function AppShell({role,children}:{role:'customer'|'rider'|'admin',children:React.ReactNode}){return <div className="app-shell"><Sidebar role={role}/><main className="main">{children}</main></div>}
