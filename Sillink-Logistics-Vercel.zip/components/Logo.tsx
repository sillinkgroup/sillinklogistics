'use client'; export default function Logo({small=false}:{small?:boolean}){return <img src="/logo.png" alt="Sillink Logistics" style={{width:small?64:88,height:'auto'}}/>}
