export const shipments=[
 {id:'SLK-NG-482910',route:'Lagos → Abuja',recipient:'Daniel Obi',status:'In Transit',amount:'₦18,500',date:'Today'},
 {id:'SLK-NG-482911',route:'Abuja → Lagos',recipient:'Mary James',status:'Pending',amount:'₦12,800',date:'Today'},
 {id:'SLK-NG-482912',route:'Lagos → Port Harcourt',recipient:'Ada Okoro',status:'Delivered',amount:'₦15,200',date:'Yesterday'},
 {id:'SLK-NG-482913',route:'Abuja → Enugu',recipient:'Chris Eze',status:'Out for Delivery',amount:'₦9,400',date:'Yesterday'},
 {id:'SLK-NG-482914',route:'Lagos → Kano',recipient:'Bello Musa',status:'Pending',amount:'₦21,600',date:'Yesterday'},
];
export const users=['Inspiremepayadmin','Mr Rosemont','emmanuelchukwu2024','Bello Musa','Daniel Eze','Chris Eze','Emma Brown','Ada Okafor'];
export const navByRole={customer:[['Dashboard','/dashboard'],['Book a Shipment','/customer/book'],['My Shipments','/customer/shipments'],['Track Package','/customer/track'],['My Profile','/customer/profile']],rider:[['My Profile','/rider/profile'],['My Tasks','/rider/tasks'],['Messages','/rider/messages'],['My Earnings','/rider/earnings']],admin:[['My Profile','/admin/profile'],['Overview','/admin/overview'],['Inbox','/admin/inbox'],['Shipments','/admin/shipments'],['Dispatch','/admin/dispatch'],['Riders','/admin/riders'],['Users','/admin/users'],['Payments','/admin/payments'],['Blog','/admin/blog'],['Settings','/admin/settings']]};
