import {NextResponse} from 'next/server'; import {shipments} from '@/lib/data';
export async function GET(){return NextResponse.json({ok:true,shipments})}
export async function POST(req:Request){const body=await req.json().catch(()=>({})); const shipment={id:'SLK-NG-'+Math.floor(100000+Math.random()*899999),route:`${body.pickup||'Lagos'} → ${body.destination||'Abuja'}`,recipient:body.recipient||'Customer',status:'Pending',amount:'₦1,500',date:'Today',...body}; return NextResponse.json({ok:true,shipment},{status:201})}
