import {NextResponse} from 'next/server';
export async function POST(req:Request){const body=await req.json().catch(()=>({})); const role=body.role||'customer'; return NextResponse.json({ok:true,user:{id:'demo-'+role,email:body.email||'demo@example.com',role}})}
